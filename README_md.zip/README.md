# Mini Secure App

Demo project: Node.js backend + Web frontend + Android WebView app
